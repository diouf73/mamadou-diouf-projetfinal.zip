package sn.exemple.covid_project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class personal_info extends menu {
    private TextView nom2, prenom2,adresse2, telephone2;
    private EditText edite2, edite3,edite4,edite5,edite6;
    private Button sms;
    private DtatabaseMenager dtatabaseMenager;
    private Object DtatabaseMenager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);

        nom2=(TextView)findViewById(R.id.nom2);
        prenom2=(TextView)findViewById(R.id.prenom2);
        adresse2=(TextView)findViewById(R.id.adresse2);
        telephone2=(TextView)findViewById(R.id.telephone2);

        DtatabaseMenager= new DtatabaseMenager(this);
        dtatabaseMenager.close();
    }


}