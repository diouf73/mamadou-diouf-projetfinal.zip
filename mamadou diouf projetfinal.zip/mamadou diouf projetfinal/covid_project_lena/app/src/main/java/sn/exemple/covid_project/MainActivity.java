package sn.exemple.covid_project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends menu {
   private TextView textView24;
   private ImageView imageView2;
   private Button button1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView24 = (TextView) findViewById(R.id.textView24);
        imageView2 = (ImageView) findViewById(R.id.imageView2);
        button1= (Button) findViewById(R.id.button1);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), presentation.class);
                startActivity(intent);
            }
        });

    }

    /*@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.option_de_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.itm_apropos:
                Toast.makeText(this, "a propos selected", Toast.LENGTH_LONG).show();
                Intent i = new Intent(getApplicationContext(), A_propos.class);
                startActivity(i);
                return true;
            case R.id.itm_contact:
                Toast.makeText(this, "contact selected", Toast.LENGTH_LONG).show();
                Intent in= new Intent(getApplicationContext(), Contact.class);
                startActivity(in);
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }
    }*/

}