package sn.exemple.covid_project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class A_propos extends menu {
    private TextView ma;
    private TextView df;
    private TextView scp;
    private TextView email;
    private TextView num;
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_a_propos);

        ma=(TextView)findViewById(R.id.ma);
        df=(TextView)findViewById(R.id.df);
        scp=(TextView)findViewById(R.id.scp);
        email=(TextView)findViewById(R.id.email);
        num=(TextView)findViewById(R.id.num);

    }
}