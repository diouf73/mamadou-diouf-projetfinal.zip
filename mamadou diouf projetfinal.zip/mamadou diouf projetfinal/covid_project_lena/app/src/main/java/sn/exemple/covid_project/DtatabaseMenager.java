package sn.exemple.covid_project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;


public class DtatabaseMenager extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "PROJETFINAL";
    private static final int DATABASE_VERSION = 1;

    // nom base de données

    // Nom Table : Note.
    private static final String TABLE_PERSONNE = "contact";

    private static final String COLUMN_NOM ="nom";
    private static final String COLUMN_PRENOM = "prenom";
    private static final String COLUMN_ADRESSE = "adresse";
    private static final String COLUMN_PROFESSION = "telephone";



    public DtatabaseMenager(Context context){
        super(context,DATABASE_NAME,null,DATABASE_VERSION);
    }



    @Override
    public void onCreate(SQLiteDatabase db) {
        String strsql = "CREATE TABLE  contacts("
                + "nom text not null,"
                + "prenom text not null,"
                + "adresse text not null,"
                + "telephone interger primary key"+
                ")";
        // Execution Script.
        db.execSQL(strsql);
        Log.i("DATABASE","onCreate invoked");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}

