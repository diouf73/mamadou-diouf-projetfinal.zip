package sn.exemple.covid_project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class Dernier_resultat extends AppCompatActivity {
    private TextView textView16;
    private TextView textView22;
    private ImageView imageView3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dernier_resultat);

        textView16=(TextView)findViewById(R.id.textView16);
        textView22=(TextView)findViewById(R.id.textView22);
        imageView3=(ImageView)findViewById(R.id.imageView3);
    }
}